#!/usr/bin/env python3

"""This is the main entry point for the BAM package."""

import sys

