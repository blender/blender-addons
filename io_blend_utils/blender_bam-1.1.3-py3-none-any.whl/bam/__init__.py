# -*- coding: utf-8 -*-

__version__ = '1.1.3'

if __name__ == '__main__':
    from .cli import main

    main()
